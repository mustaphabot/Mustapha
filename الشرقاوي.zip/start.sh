python3 -m zira
